VYNORAMEDIA — CUSTOMIZED WEBSITE STARTER

WhatsApp number configured:
0333 3666465 -> international wa.me format: 923333666465

SERVICES
- Photography
- Videography
- Video editing
- Social media content

CURRENT FUNCTIONALITY
- Responsive one-page website
- Mobile navigation
- Services and portfolio sections
- Contact enquiry form that opens a prefilled WhatsApp message
- Payment information section

IMPORTANT PAYMENT STATUS
A real online payment gateway is NOT integrated. A payment gateway needs a provider account, business verification, and a secure integration/checkout flow. Do not collect card numbers, CVV, or payment credentials in this static website.
For Pakistan, first contact payment providers and confirm eligibility, business requirements, settlement terms, and whether they offer hosted checkout/payment links or APIs for your business. Keep secret API keys on a backend/serverless function, never in index.html.
A low-budget first step is to invoice clients and send a provider-issued payment link after the quote is approved; integrate checkout later.

PUBLISH FOR FREE (GitHub Pages)
1. Download and unzip vynoramedia_website.zip.
2. Visit https://github.com and create/sign in to an account.
3. Create a new public repository named vynoramedia-website.
4. Upload index.html from this folder to the repository root (README.txt is optional).
5. Open repository Settings -> Pages.
6. Under Build and deployment, choose "Deploy from a branch".
7. Select branch "main" and folder "/ (root)", then Save.
8. Wait for the deployment to complete. Your site URL will look like:
   https://YOUR-USERNAME.github.io/vynoramedia-website/
9. Open the link on mobile and test all navigation links and the WhatsApp form.
10. You can later connect a custom domain from Settings -> Pages if you purchase one.

ALTERNATIVE: NETLIFY FREE STATIC HOSTING
1. Sign in at https://app.netlify.com/.
2. Choose Add new site / Deploy manually (wording may vary).
3. Drag and drop the unzipped website folder containing index.html into the deploy area.
4. Use the generated *.netlify.app URL to test.
5. Set a custom domain later if desired.

BEFORE GOING LIVE
- Replace sample portfolio images with your own authorized project photos/videos.
- Confirm service wording and contact details.
- Add your privacy policy and terms if you collect personal data or accept payments.
- Add real payment checkout only after provider approval and secure integration.
- The website currently has no backend, admin dashboard, database, order tracking, or payment processing.
